#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
[[ -x "$ROOT/bin/residctl_llama" ]] || { echo 'Run bash setup.sh first.' >&2; exit 2; }
[[ -x /usr/bin/time ]] || { echo 'Install the Ubuntu time package first (see README.md).' >&2; exit 2; }
TOKENS=${TOKENS:-32}
THREADS=${THREADS:-8}
TOTAL_CAP_MIB=${TOTAL_CAP_MIB:-768}
RUN_TIMEOUT=${RUN_TIMEOUT:-120}
for v in "$TOKENS" "$THREADS" "$TOTAL_CAP_MIB" "$RUN_TIMEOUT"; do
    [[ $v =~ ^[1-9][0-9]*$ ]] || { echo 'Token/thread/cap/timeout settings must be positive integers.' >&2; exit 2; }
done
RUN_ID="$(date +%Y%m%d-%H%M%S)-$$"
OUT="$ROOT/results/$RUN_ID"
mkdir -p "$OUT"
printf '%s\n' "$OUT" > "$ROOT/LAST_RESULTS.txt"
{
    uname -a
    date --iso-8601=seconds
    command -v lscpu >/dev/null && lscpu
    printf '\nExperiment: diagnostic; no cache reset; native/full-fit/192 MiB sequentially.\n'
    printf 'tokens=%s threads=%s total_cap_mib=%s timeout_s=%s\n' "$TOKENS" "$THREADS" "$TOTAL_CAP_MIB" "$RUN_TIMEOUT"
} > "$OUT/environment.txt"
cp -- "$ROOT/setup-logs/model-identity.txt" "$ROOT/setup-logs/runner-sha256.txt" "$ROOT/setup-logs/llama-revision.txt" "$OUT/"
echo "Results: $OUT"
echo 'This will run native, full-fit pager (384 MiB), then pager (192 MiB), each in a fresh 768 MiB cgroup by default.'
PRIV=()
if [[ $EUID -ne 0 ]]; then
    sudo -v
    PRIV=(sudo)
fi
for ARM in native full384 pager192; do
    mkdir -p "$OUT/$ARM"
    echo "Running $ARM ..."
    set +e
    "${PRIV[@]}" bash "$ROOT/run_one.sh" "$ROOT" "$OUT/$ARM" "$ARM" "$RUN_ID" \
        "$TOKENS" "$THREADS" "$TOTAL_CAP_MIB" "$RUN_TIMEOUT" > "$OUT/$ARM/launcher.log" 2>&1
    RC=$?
    set -e
    if [[ $RC -ne 0 ]]; then
        cat "$OUT/$ARM/launcher.log"
        [[ ! -f "$OUT/$ARM/runner.log" ]] || tail -n 35 "$OUT/$ARM/runner.log"
        echo "Stopped after $ARM failed (exit $RC). Existing results preserved at $OUT."
        exit "$RC"
    fi
done
python3 "$ROOT/summarize.py" "$OUT"
echo "Send the entire result folder: $OUT"
