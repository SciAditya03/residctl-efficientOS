#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
cd "$ROOT"
case "$ROOT" in /mnt/*) echo 'Extract this kit into the Linux filesystem, e.g. ~/projects, then retry.' >&2; exit 2;; esac
for tool in git cmake gcc g++ make curl python3 patch sha256sum; do
    command -v "$tool" >/dev/null || { echo "Missing dependency: $tool. See README.md." >&2; exit 2; }
done
python3 - "$ROOT" <<'PY'
import hashlib,json,pathlib,sys
r=pathlib.Path(sys.argv[1]);m=json.loads((r/'SOURCE_MANIFEST.json').read_text())
for name,want in m['files'].items():
    if hashlib.sha256((r/'reference-source'/name).read_bytes()).hexdigest()!=want:
        raise SystemExit('Bundled source changed: '+name+'; use a fresh kit for the baseline.')
print('Bundled original source hashes verified.')
PY
mkdir -p models work bin setup-logs
MODEL_NAME=Qwen2.5-0.5B-Instruct-Q3_K_S.gguf
MODEL_SHA=468787b643ef9081a75c6e7bd98da987f46583250248e0a0a7aca173308e8d34
MODEL_URL=https://huggingface.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/resolve/d71b21e09fe053c278d73092a855b8a99684693a/Qwen2.5-0.5B-Instruct-Q3_K_S.gguf
if [[ ! -f models/$MODEL_NAME ]]; then
    curl --fail --location --retry 3 --connect-timeout 30 "$MODEL_URL" -o "models/$MODEL_NAME.part"
    printf '%s  %s\n' "$MODEL_SHA" "models/$MODEL_NAME.part" | sha256sum -c -
    mv -- "models/$MODEL_NAME.part" "models/$MODEL_NAME"
fi
printf '%s  %s\n' "$MODEL_SHA" "models/$MODEL_NAME" | sha256sum -c -
stat -c 'Downloaded model size: %s bytes' "models/$MODEL_NAME"
printf 'url=%s\nsha256=%s\n' "$MODEL_URL" "$MODEL_SHA" > setup-logs/model-identity.txt

REV=cae63579b67a2c51f160705956abbc8e8ebec458
LC="$ROOT/work/llama.cpp"
BUILD="$ROOT/work/llama-build"
if [[ ! -d "$LC/.git" ]]; then
    git init "$LC"
    git -C "$LC" remote add origin https://github.com/ggml-org/llama.cpp.git
    git -C "$LC" fetch --depth 1 origin "$REV"
    git -C "$LC" checkout --detach FETCH_HEAD
fi
[[ $(git -C "$LC" rev-parse HEAD) == "$REV" ]] || { echo 'Unexpected llama.cpp revision in this kit. Stop and inspect.' >&2; exit 2; }
PATCH="$ROOT/reference-source/src/integrations/llama/llama_mmap_hook.patch"
if ! grep -q residctl_llama_mmap "$LC/src/llama-mmap.cpp"; then
    patch --dry-run --batch --forward -p0 -d "$LC" < "$PATCH"
    patch --batch --forward -p0 -d "$LC" < "$PATCH"
fi
git -C "$LC" diff --check
git -C "$LC" rev-parse HEAD > setup-logs/llama-revision.txt
git -C "$LC" diff > setup-logs/llama-hook.diff
cmake -S "$LC" -B "$BUILD" -DBUILD_SHARED_LIBS=ON \
    -DGGML_CUDA=OFF -DGGML_NATIVE=ON -DLLAMA_CURL=OFF \
    -DCMAKE_BUILD_TYPE=Release -DLLAMA_BUILD_TESTS=OFF \
    2>&1 | tee setup-logs/cmake.log
cmake --build "$BUILD" --parallel "${BUILD_JOBS:-4}" --target llama \
    2>&1 | tee setup-logs/llama-build.log

SRC="$ROOT/reference-source/src"
OBJ="$ROOT/work/pager-obj"
mkdir -p "$OBJ"
PAGER_C=(core/region.c core/pager.c core/fetch.c core/budget.c
    observability/trace.c observability/metrics.c observability/cgroup_stat.c
    policy/policy.c prefetch/prefetch.c prefetch/prefetch_pool.c
    observability/fetch_trace.c observability/policy_trace.c)
INCLUDES=(-I"$SRC/core" -I"$SRC/observability" -I"$SRC/policy" -I"$SRC/prefetch" -I"$SRC"
    -I"$LC/include" -I"$LC/ggml/include")
OBJECTS=()
for f in "${PAGER_C[@]}" integrations/llama/residctl_llama.c; do
    obj="$OBJ/$(basename "$f" .c).o"
    gcc -O2 -g -pthread -Wall -Wextra "${INCLUDES[@]}" -c "$SRC/$f" -o "$obj"
    OBJECTS+=("$obj")
done
g++ -O2 -g -std=c++17 -pthread "${INCLUDES[@]}" \
    -c "$SRC/integrations/llama/llama_runner.cpp" -o "$OBJ/llama_runner.o"
g++ -O2 -g -pthread -o "$ROOT/bin/residctl_llama" "$OBJ/llama_runner.o" "${OBJECTS[@]}" \
    -Wl,--export-dynamic -L"$BUILD/bin" -Wl,-rpath,"$BUILD/bin" \
    -lllama -lggml -lggml-base -lggml-cpu -ldl -lpthread -lm
ldd "$ROOT/bin/residctl_llama" | tee setup-logs/linkage.txt
nm -D "$ROOT/bin/residctl_llama" | grep ' T residctl_llama_mmap$'
sha256sum "$ROOT/bin/residctl_llama" > setup-logs/runner-sha256.txt
echo 'Setup complete. Next: bash run.sh'
