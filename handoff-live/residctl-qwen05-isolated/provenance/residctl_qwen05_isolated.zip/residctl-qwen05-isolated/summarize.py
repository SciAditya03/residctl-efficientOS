#!/usr/bin/env python3
"""Summarize recorded files without claiming statistical significance or identical I/O semantics."""
import json
import pathlib
import re
import sys


def fields(text, prefix):
    rows = [line for line in text.splitlines() if line.startswith(prefix + ',')]
    if len(rows) != 1:
        raise ValueError(f'Expected one {prefix} record; found {len(rows)}')
    return dict(item.split('=', 1) for item in rows[0].split(',')[1:] if '=' in item)


def cgroup_peak(text):
    leaf = text.rsplit('\nGROUP=', 1)[-1]
    match = re.search(r'\nmemory\.peak:\n(\d+)', leaf)
    return int(match[1]) if match else None


def main():
    root = pathlib.Path(sys.argv[1])
    result = {'protocol': 'single diagnostic run per arm, sequential, no cache reset', 'arms': {}}
    token_lists = {}
    for arm in ['native', 'full384', 'pager192']:
        p = root / arm
        log = (p / 'runner.log').read_text(errors='replace')
        rec = fields(log, 'WP2_CSV')
        expected = 'mmap' if arm == 'native' else 'residctl'
        if rec.get('arm_mode') != expected:
            raise ValueError(f'{arm}: unexpected arm_mode')
        if int((p / 'exit-code.txt').read_text()) != 0:
            raise ValueError(f'{arm}: nonzero process exit')
        peak = cgroup_peak((p / 'cgroup-after.txt').read_text())
        time_text = (p / 'process-time.txt').read_text(errors='replace')
        rss = re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)', time_text)
        data = {'runner_metrics': rec, 'cgroup_peak_bytes': peak,
                'time_maxrss_kib': int(rss[1]) if rss else None}
        toks = [int(x) for x in (p / 'tokens.txt').read_text().split()]
        if len(toks) != int(rec['n_decoded']):
            raise ValueError(f'{arm}: token file count differs from n_decoded')
        token_lists[arm] = toks
        if arm != 'native':
            data['pager_metrics'] = fields(log, 'RESIDCTL_STATS')
        result['arms'][arm] = data
    result['token_parity'] = {arm: token_lists[arm] == token_lists['native']
                              for arm in ['full384', 'pager192']}
    (root / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print('\nArm          output N   prefill-inclusive tok/s   TTFT ms    cgroup peak MiB')
    for arm, data in result['arms'].items():
        rec = data['runner_metrics']
        peak = data['cgroup_peak_bytes']
        peak_text = f'{peak / 1048576:.2f}' if peak is not None else 'unavailable'
        print(f"{arm:12} {rec['n_decoded']:>8} {rec['tokens_s']:>25} {rec['ttft_ms']:>10} {peak_text:>18}")
    for arm, equal in result['token_parity'].items():
        print(f'{arm} token IDs identical to native: {equal}')
    full = result['arms']['full384']['pager_metrics']
    print('Full-fit pager evictions:', full.get('evictions', 'missing'))
    if full.get('evictions') != '0':
        print('Unexpected full-fit evictions: inspect inventory/config before interpreting timings.')
    print('Inspect raw logs; failures/availability and cache state are not inferred from a zero counter.')
    if not all(result['token_parity'].values()):
        raise SystemExit('OUTPUT MISMATCH: stop performance interpretation and send this result folder.')


if __name__ == '__main__':
    main()
