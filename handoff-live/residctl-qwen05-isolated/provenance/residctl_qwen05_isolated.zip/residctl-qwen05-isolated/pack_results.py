#!/usr/bin/env python3
import pathlib
import zipfile

root = pathlib.Path(__file__).resolve().parent
marker = root / 'LAST_RESULTS.txt'
if not marker.exists():
    raise SystemExit('No run found yet. If setup failed, send its terminal error and setup-logs instead.')
run = pathlib.Path(marker.read_text().strip()).resolve()
if run.parent != root / 'results' or not run.is_dir():
    raise SystemExit('Invalid last-results path; no files packed.')
out = root / ('qwen05-results-' + run.name + '.zip')
with zipfile.ZipFile(out, 'x', zipfile.ZIP_DEFLATED) as z:
    for folder in [run, root / 'setup-logs']:
        if folder.exists():
            for p in sorted(folder.rglob('*')):
                if p.is_file() and not p.is_symlink():
                    z.write(p, p.relative_to(root))
    for name in ['SOURCE_MANIFEST.json', 'README.md', 'setup.sh', 'run.sh', 'run_one.sh', 'summarize.py']:
        z.write(root / name, name)
print(out)
