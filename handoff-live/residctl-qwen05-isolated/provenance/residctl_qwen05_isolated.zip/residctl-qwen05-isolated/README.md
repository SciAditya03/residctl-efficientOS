# Isolated Qwen 0.5B diagnostic run

Prepared 29 October 2026 for your residctl project. This kit contains unchanged C/C++ source and headers from your uploaded `scratch.zip`, plus a separate build/run harness. It does not use a remote residctl branch or assume that your current working tree is clean. `SOURCE_MANIFEST.json` identifies the exact source snapshot. This is an independent source snapshot, not a new contribution to the pager algorithm.

## What you will run

| Arm | Weight budget | Total cgroup cap | Purpose |
|---|---:|---:|---|
| native | Linux-managed | 768 MiB | Native mmap path of the same instrumented runner |
| full384 | 384 MiB | 768 MiB | Pager with room for the entire ~323 MiB mapped model |
| pager192 | 192 MiB | 768 MiB | Pager under your friend's weight-budget setting |

Each arm gets a new uniquely named cgroup, swap disabled, CPU-only inference, eight inference threads, 32 requested output tokens, and the prompt `The operating system manages memory by`. Pager arms use declared order, prefetch off, one fetch worker, protect_current off, and pre-consumption signals as implemented in your original integration. The final summary compares token IDs exactly.

This is a short diagnosis, not a statistical performance campaign or proof of a constrained-memory benefit. The 768 MiB cap is a common generous pilot allowance, not a measured minimum. Parent/VM limits still apply and are recorded where readable. Native is not forced below its working set here. The source's generation throughput includes prompt evaluation; TTFT excludes model loading/context setup.

## Isolation

Extract under your WSL Ubuntu Linux home filesystem, for example `~/projects/residctl-qwen05-isolated`. Do not extract under `/mnt/c` or inside your current residctl project. A separate Git clone is unnecessary because the kit already supplies the exact original source snapshot.

- Model: this kit's `models/Qwen2.5-0.5B-Instruct-Q3_K_S.gguf`.
- Dependency source/build: this kit's `work/llama.cpp` and `work/llama-build`.
- Executable: this kit's `bin/residctl_llama`.
- Results/configs: new timestamped directories under this kit's `results`.
- Cgroups: fresh `/sys/fs/cgroup/residctl_qwen05_<run-id>_<arm>` leaves, removed only when empty after final snapshots.
- No existing model is renamed/replaced. No original project source, current build, existing cgroup, global sysctl, or global page cache is changed.
- All three tests use the real machine's CPU, RAM, and storage. Stop other heavy benchmarks first; directory isolation does not isolate hardware performance.

Use `sudo` only where shown. The kit supports an existing root WSL login directly. With a normal user, the run launcher requests sudo for new cgroups and userfaultfd, matching your friend's successful root runs. Setup does not need privilege but also accepts an existing root login. It does not enable userfaultfd through a global sysctl. If WSL/kernel support is insufficient, it stops and saves the error instead of silently using another mechanism.

## 1. Install build prerequisites in WSL Ubuntu

Run these in the Ubuntu terminal, not PowerShell:

```bash
sudo apt update
sudo apt install -y build-essential cmake git curl patch python3 unzip time
```

These package installations are shared system dependencies. No system-wide llama.cpp installation is performed. The default build uses four parallel jobs; use `BUILD_JOBS=2 bash setup.sh` if RAM is tight.

## 2. Extract the downloaded kit

For the usual Windows Downloads location, this opens the folder in Explorer from WSL:

```bash
mkdir -p "$HOME/projects"
cd "$HOME/projects"
explorer.exe .
```

Use Explorer to copy the downloaded `residctl_qwen05_isolated.zip` into the opened `projects` folder. Then, back in the same WSL terminal:

```bash
unzip residctl_qwen05_isolated.zip
cd residctl-qwen05-isolated
```

The extraction creates a new folder. If that folder already exists from an earlier attempt, use the existing kit or extract into another fresh parent folder; do not overwrite previous results inadvertently.

## 3. Download the model and build independently

```bash
bash setup.sh
```

Setup downloads exactly this artifact:

- Model: Qwen2.5-0.5B-Instruct, Q3_K_S GGUF. **0.5B is parameter count, not a 0.5 GB download.**
- Publisher: `bartowski/Qwen2.5-0.5B-Instruct-GGUF`.
- Pinned model repository revision: `d71b21e09fe053c278d73092a855b8a99684693a`.
- File size verified against Hugging Face metadata: **338,263,456 bytes**, about 322.59 MiB.
- SHA-256: `468787b643ef9081a75c6e7bd98da987f46583250248e0a0a7aca173308e8d34`.
- File page: https://huggingface.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/blob/d71b21e09fe053c278d73092a855b8a99684693a/Qwen2.5-0.5B-Instruct-Q3_K_S.gguf
- Download: https://huggingface.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/resolve/d71b21e09fe053c278d73092a855b8a99684693a/Qwen2.5-0.5B-Instruct-Q3_K_S.gguf

The variant and byte size match the friend's report. Byte-for-byte identity to his model is unconfirmed until he supplies its SHA-256. A model with the same architecture/quantization name from another publisher can have different bytes.

Setup checks the download hash, fetches llama.cpp commit `cae63579b67a2c51f160705956abbc8e8ebec458` into this kit, applies the existing mmap hook only there, and builds the unchanged pager against it. This is the revision identified in your friend's evidence, not a claim that the archived 3B experiments used this revision.

It records the dependency revision, patch diff, linkage, and runner hash. If setup reports a patch/build failure, stop and send the full error; do not substitute latest llama.cpp or run the old `/root/residctl` setup scripts.

## 4. Run the three diagnostic cases

Once setup prints `Setup complete`:

```bash
bash run.sh
```

If running as a normal user, enter your Ubuntu sudo password when prompted. An existing root login runs directly without sudo. The runs are sequential. Each has a 120-second timeout plus up to 10 seconds for termination; a failed arm stops the sequence with its files preserved. It does not kill processes in existing project cgroups. Do not launch several copies at once.

Default expected final output:

```text
Arm          output N   prefill-inclusive tok/s   TTFT ms    cgroup peak MiB
native       ...
full384      ...
pager192     ...
full384 token IDs identical to native: True
pager192 token IDs identical to native: True
Full-fit pager evictions: 0
```

The actual numbers are measured on your machine; no throughput outcome is promised. An EOS may produce fewer than 32 tokens, which the summary retains. Compare exact token counts and sequences before interpreting timings. An output mismatch is an investigation failure, not a performance result.

There is no 128 MiB run: your friend's embedding chunk alone exceeded that budget. A 160 MiB repetition is deliberately deferred until the initial diagnosis is reviewed.

## 5. What to send back

The terminal prints the full results directory. `LAST_RESULTS.txt` also stores it. To create one return ZIP containing the latest run, setup evidence, source identity, and harness:

```bash
python3 pack_results.py
```

This creates a new `qwen05-results-<run-id>.zip` in the kit directory. It excludes the model, dependency source, binaries, and build directories. Send that ZIP here. If setup failed before any run, send the terminal error and any `setup-logs` files instead.

Each run folder contains `runner.log`, exact command, token IDs, exit code, `/usr/bin/time` output, before/after cgroup snapshots, and (for pager arms) configuration plus complete model inventory. Completed three-arm runs also produce `summary.json`.

## Interpreting the outcome

- **Full-fit has zero evictions and is much closer to native; 192 MiB is slow with many evictions:** repeated fetching at low weight budget is a leading cost. It does not exclude additional overhead.
- **Full-fit is also very slow:** inspect startup faults, callback/pager overhead, I/O mode, and build/library identity; do not attribute everything to capacity eviction.
- **Token IDs differ:** first investigate data/integration correctness.
- **Pager activation markers absent or fallback warning:** invalid pager run, even if `arm_mode` claims residctl.
- **Timeout/OOM/infeasible:** failed configuration with retained diagnostics; do not silently increase the allowance for only one arm.

Memory limits versus measurements: the pager budget covers its managed residency accounting. Cgroup `memory.peak` and process max RSS from `/usr/bin/time` are different quantities and are recorded separately. Two mappings can refer to shared backing pages; RSS is not unique weight memory.

Cache/measurement limits: this kit deliberately does not drop system-wide caches. Model download/hash/build activity and preceding runs can affect the file cache and its cgroup charge attribution. Therefore the initial single runs are **cache-uncontrolled diagnostics**; cgroup peak comparisons alone do not prove a memory-saving percentage. Do not present the output as a cold-cache benchmark or a proven equal-memory advantage. A later controlled campaign can address cache preparation, per-phase counters, alternating run order, and repetitions.

`WP2_CSV.io_read_bytes_gen` is the original runner's process generation counter; it returns zero on read failure in this source, so raw availability must be checked before using a zero as proof. `pager_bytes_fetched` is the original pager's lifetime aligned-chunk byte counter, including startup; it is not automatically generation-only or physical SSD traffic. No new metric semantics are implied by this harness.

## Validation performed when preparing the kit

- Existing project policy unit tests passed.
- Existing mmap patch dry-run applies to the pinned llama.cpp revision.
- All linked pager C translation units and the inference runner pass compiler syntax/API checks against that revision's headers.
- Bash/Python harness syntax checked; the summary parser checked against synthetic fixture logs (parser validation, not real inference evidence).
- Root-login privilege selection was checked without running inference; normal-user branch syntax was reviewed.
- No end-to-end Qwen inference or cgroup/UFFD run is claimed from this preparation environment. Your WSL execution is the actual test.
