#!/usr/bin/env bash
# Internal helper. All cgroup mutation is confined to a new uniquely named leaf.
set -euo pipefail
[[ $EUID -eq 0 && $# -eq 8 ]] || { echo 'Use bash run.sh, not this helper directly.' >&2; exit 2; }
ROOT=$1; OUT=$2; ARM=$3; RUN_ID=$4; TOKENS=$5; THREADS=$6; CAP=$7; LIMIT=$8
case "$ARM" in native) BUDGET=0;; full384) BUDGET=402653184;; pager192) BUDGET=201326592;; *) exit 2;; esac
[[ $RUN_ID =~ ^[0-9-]+$ ]] || exit 2
CG="/sys/fs/cgroup/residctl_qwen05_${RUN_ID}_${ARM}"
MODEL="$ROOT/models/Qwen2.5-0.5B-Instruct-Q3_K_S.gguf"
[[ -f /sys/fs/cgroup/cgroup.controllers ]] || { echo 'cgroup v2 is required.' >&2; exit 2; }
mkdir -- "$CG"
cleanup() {
    if [[ -d "$CG" && -z $(cat "$CG/cgroup.procs" 2>/dev/null) ]]; then
        rmdir -- "$CG" || true
    else
        echo "Cgroup left for inspection: $CG (no unrelated processes were killed)." >&2
    fi
}
trap cleanup EXIT
[[ -f "$CG/memory.max" && -f "$CG/memory.swap.max" ]] || {
    echo 'The memory controller is unavailable in the new cgroup. Stop; send this log. No global controller setting was changed.' >&2; exit 2;
}
printf '%s\n' "$((CAP * 1048576))" > "$CG/memory.max"
printf 'max\n' > "$CG/memory.high"
printf '0\n' > "$CG/memory.swap.max"
snapshot() {
    local DEST=$1
    {
        date --iso-8601=seconds
        for GROUP in /sys/fs/cgroup "$CG"; do
            printf '\nGROUP=%s\n' "$GROUP"
            for FIELD in memory.max memory.high memory.swap.max memory.current memory.peak memory.events memory.stat io.stat cpu.stat cpu.max cpuset.cpus.effective; do
                printf '\n%s:\n' "$FIELD"
                if [[ -r "$GROUP/$FIELD" ]]; then cat "$GROUP/$FIELD"; else echo UNAVAILABLE; fi
            done
        done
    } > "$DEST"
}
snapshot "$OUT/cgroup-before.txt"
CFG="$OUT/pager.conf"
if [[ $ARM != native ]]; then
    cat > "$CFG" <<EOF
model=$MODEL
cgroup=$CG
budget_bytes=$BUDGET
policy=layer_order_declared
prefetch=off
retention=pinned
fetch_workers=1
fetching_timeout_ms=5000
protect_current=off
eager_reconcile=0
EOF
fi
CMD=(/usr/bin/env -u RESIDCTL_CONFIG "LD_LIBRARY_PATH=$ROOT/work/llama-build/bin")
[[ $ARM == native ]] || CMD+=("RESIDCTL_CONFIG=$CFG")
CMD+=("$ROOT/bin/residctl_llama" -m "$MODEL" -n "$TOKENS" -t "$THREADS"
    -p 'The operating system manages memory by' --dump-tokens "$OUT/tokens.txt")
[[ $ARM == native ]] || CMD+=(--inventory "$OUT/inventory.txt")
{
    printf 'cgroup=%s\nweight_budget_bytes=%s\n' "$CG" "$BUDGET"
    printf 'command='; printf '%q ' "${CMD[@]}"; printf '\n'
    printf 'No guest cache reset was performed. Model loading is excluded from WP2 generation timing.\n'
} > "$OUT/command.txt"
set +e
bash -c 'set -e; printf "%s\n" "$$" > "$1/cgroup.procs"; shift; exec "$@"' -- "$CG" \
    /usr/bin/timeout --signal=TERM --kill-after=10s "${LIMIT}s" \
    /usr/bin/time -v -o "$OUT/process-time.txt" "${CMD[@]}" > "$OUT/runner.log" 2>&1
RC=$?
set -e
printf '%s\n' "$RC" > "$OUT/exit-code.txt"
snapshot "$OUT/cgroup-after.txt"
[[ $RC -eq 0 ]] || { echo "$ARM exited $RC; see runner.log and cgroup-after.txt." >&2; exit "$RC"; }
if [[ $ARM != native ]]; then
    grep -q 'residctl_llama: region up\.' "$OUT/runner.log" && grep -q '^RESIDCTL_STATS,' "$OUT/runner.log" || {
        echo 'Pager activation was not confirmed. Do not treat this as a pager result.' >&2; exit 3;
    }
    if grep -q 'using plain mmap' "$OUT/runner.log"; then echo 'Unexpected native fallback.' >&2; exit 3; fi
fi
grep -q "^WP2_CSV,arm_mode=" "$OUT/runner.log" || { echo 'Missing timing summary.' >&2; exit 3; }
