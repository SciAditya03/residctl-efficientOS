# Live native-versus-residctl Qwen comparison

This adds actual token streaming and a terminal display to the isolated build you already ran successfully. It uses the **same existing GGUF** in two mapping modes, sequentially. It does not create a second AI model or modify the pager algorithm.

## Exact steps on your WSL machine

You are already logged in as root. Keep using that terminal. This CLI needs root for cgroups and userfaultfd. It is not a web server.

1. Download `residctl_live_compare.zip` and copy it into your Linux home folder (`/root`) using Windows Explorer. To open that location from WSL:

```bash
cd /root
explorer.exe .
```

2. Extract it separately:

```bash
cd /root
unzip residctl_live_compare.zip
cd residctl-live-compare
```

If that directory already exists from a previous attempt, use the existing directory or extract in another fresh parent. Do not overwrite saved result folders.

3. Confirm the existing larger model's path and file size:

```bash
stat -c '%n : %s bytes' /root/residctl/models/model.gguf
```

For the earlier Qwen2.5-3B Q4_K_M, the archived size was **2,104,932,768 bytes**. If this command fails, locate the actual existing GGUF before proceeding. A 338,263,456-byte file is the smaller 0.5B model, not the earlier 3B model.

4. Run one real question through both modes:

```bash
python3 live_compare.py \
  --kit /root/residctl/residctl_qwen05_isolated/residctl-qwen05-isolated \
  --model /root/residctl/models/model.gguf \
  --tokens 16 \
  --cap-mib 1800 \
  --weight-ratio 0.75 \
  --prompt "Explain virtual memory in one short sentence."
```

The `--kit` path is the successful isolated experiment folder shown in your terminal. It reuses that kit's already built C objects and patched llama.cpp libraries, but builds a **new executable inside this live-demo folder**. It does not replace `bin/residctl_llama` or edit its source.

The `--model` path must be your actual existing 3B GGUF. You do not need to download it again. The tool makes a separate ordinary file copy into its own `models/` folder once, so reserve approximately 2.1 GB of additional free disk space. It then records the copy's SHA-256. This copy and setup are preparation, not part of reported inference timing.

5. To ask your own question interactively, omit `--prompt`:

```bash
python3 live_compare.py \
  --kit /root/residctl/residctl_qwen05_isolated/residctl-qwen05-isolated \
  --model /root/residctl/models/model.gguf \
  --tokens 16 --cap-mib 1800 --weight-ratio 0.75
```

It asks `Enter your question:` and uses your answer for both runs. Start with a short question. Sixteen is an output-token limit, so a sentence may be cut off; change to `--tokens 32` for more text after the first successful rehearsal. No search/retrieval is connected to this model.

## What appears live

Run directly in the terminal; do not pipe through `tee` if you want the updating screen. Logs are saved automatically.

- Model size and memory settings.
- Native first, then residctl; each has its own elapsed timer and phase.
- Actual generated text, updated as output tokens arrive.
- Actual completed token count, not a simulated progress bar.
- Current memory charged to the active cgroup, then peak charged memory after completion.
- At completion: generation duration, launch-to-exit duration, throughput, memory peak, and exact output token-ID equality.

Preparation, model loading, context creation, generation, and shutdown are distinct. Total live elapsed time includes process startup/loading/context/generation/shutdown. Original `WP2_CSV.wall_s` is generation time including prompt evaluation, excluding model loading/context setup. The saved summary also records launch-to-first-token and first-to-last-token throughput. Token conversion and event delivery add some overhead; this is a **live demonstration**, not a replacement for an uninstrumented benchmark campaign.

Qwen's ChatML prompt wrapper is used for a question/answer interaction. Both modes receive identical wrapped bytes. `--raw-prompt` disables that wrapper if you want a raw completion or the archived raw prompt instead. New questions and prompt formatting mean the old recorded timings are estimates, not a promised runtime.

## Comparison settings

Default CLI settings: 16 requested output tokens, eight inference threads, CPU only, 1800 MiB **total cap for both modes**, and a pager weight budget equal to 75% of aligned model-file size. For the archived 3B file that weight budget is about 1506 MiB. The remaining allowance is runtime headroom, not a guaranteed sufficient amount for every context or model.

Native uses the same instrumented runner with `RESIDCTL_CONFIG` unset. residctl uses declared order, prefetch off, four fetch workers, protect_current off, and the existing pre-consumption notification mechanism. This is the native-versus-pager experiment you requested; it is **not** the earlier LRU-versus-declared-order experiment.

There is no promised winner. If the native model fits in available memory, native may be faster. To perform a generous-memory context comparison later, repeat the same command with `--cap-mib 3072`; the pager remains at its explicitly selected 75% weight budget. Preserve and label each run's settings rather than comparing arbitrary rows from different experiments.

## Cache preparation and limits

The first diagnostic showed native model pages could be charged outside its fresh cgroup. This demo addresses that specific problem before each arm:

1. Uses its own model-file copy, separate from your original model.
2. Calls fsync on that copy and requests **per-file** POSIX_FADV_DONTNEED.
3. Checks backing-page residency with mincore, without touching model bytes.
4. Requires no more than 16 pages to remain resident before launching. Otherwise it stops with the evidence preserved.
5. Creates a fresh cgroup and joins it before executing the inference runner. It does not read/hash the model between the cache check and launch.

This is Linux guest file-cache preparation. It does not control Windows/WSL host caches or measure physical SSD controller traffic. File-discard advice is not a universal guarantee; that is why the observable residency check is required. A few permitted residual pages are explicitly recorded. Native readahead can populate the model **after launch**, inside the experiment, as intended.

No system-wide drop_caches, existing cgroup, current project source/build, or original model file is changed. Hardware resources are shared: stop other model runs before rehearsing. Runtime libraries and other shared data can still have external cache charges; the check targets the large model-file confound, not perfect machine-wide accounting.

## Results and errors

Every attempt gets a new `results/<timestamp>-<pid>/` folder. Completed pairs create a ZIP automatically and print its full path. Send that ZIP here after the rehearsal. It contains full raw logs, actual output/token IDs, timestamped token events, memory samples, configurations, commands, cache checks, cgroup snapshots, and the streaming runner source. It excludes the model and dependency/build files.

Both runs have a 180-second timeout by default; use `--timeout 300` only if a rehearsal establishes a legitimate need. A timeout/OOM/mapping fallback/nonempty-token mismatch stops the comparison and preserves existing files. Do not silently give only one mode a larger cap.

Ctrl+C stops only the current demo process group. The driver removes only its own empty cgroup. On interruption or error, inspect the printed partial-result folder. It does not kill unrelated inference processes.

If the original 3B file is absent, do not point this command at the 0.5B file and label it 3B. If the kit path is absent, provide the actual successful kit directory. If the cache check or new build fails, send that error before changing kernels, libraries, or pager code.

## Validation before delivery

- Generated streaming runner passes compiler syntax/API checks against the pinned llama.cpp headers.
- Source modifications are limited to output-token conversion/events and phase/PID markers; the original source file and pager C objects are not edited.
- Python syntax checked. Per-file discard/mincore observer verified on a small real temporary file: populated pages were observed, then discarded, and an actual subsequent read increased observed residency.
- Launcher ordering checked: a newline-terminated PID is written to the selected cgroup path before exec.
- Streaming control flow checked with a temporary protocol fixture, including split UTF-8 token pieces, saved token IDs, raw logs, and activation checks. Fixture outputs are not inference measurements.
- No end-to-end 3B inference/cgroup run is claimed in this preparation environment. Your WSL rehearsal supplies that validation.

References for the preparation interfaces:
- https://man7.org/linux/man-pages/man2/posix_fadvise.2.html
- https://man7.org/linux/man-pages/man2/mincore.2.html
- https://docs.kernel.org/admin-guide/cgroup-v2.html#memory-ownership
